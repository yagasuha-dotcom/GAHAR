const express = require('express');
const axios = require('axios');
const cors = require('cors');
const cheerio = require('cheerio');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// BASE URL KURAMANIME (update jika domain berubah)
const BASE_URL = 'https://kuramanime.com';

// Helper: fetch HTML dan load Cheerio
async function fetchHTML(url) {
    try {
        const { data } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 10000
        });
        return cheerio.load(data);
    } catch (err) {
        throw new Error(`Gagal mengakses ${url}: ${err.message}`);
    }
}

// ========== ENDPOINT 1: Anime Terbaru (Beranda) ==========
app.get('/api/latest', async (req, res) => {
    try {
        const $ = await fetchHTML(BASE_URL);
        const results = [];
        $('.anime-list .anime-item, .list-anime .anime-item, .anime-card').each((i, el) => {
            const title = $(el).find('.anime-title, .title, h3').text().trim();
            const link = $(el).find('a').attr('href');
            const image = $(el).find('img').attr('src');
            const episode = $(el).find('.episode, .eps').text().trim();
            if (title && link) {
                results.push({
                    title,
                    link: link.startsWith('http') ? link : BASE_URL + link,
                    image: image || 'https://via.placeholder.com/180x260?text=No+Image',
                    episode: episode || '?'
                });
            }
        });
        res.json(results.length ? results : [{ message: 'Tidak ada data, coba periksa struktur website' }]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== ENDPOINT 2: Pencarian ==========
app.get('/api/search', async (req, res) => {
    const query = req.query.q;
    if (!query) return res.status(400).json({ error: 'Parameter q wajib diisi' });
    try {
        const $ = await fetchHTML(`${BASE_URL}/?s=${encodeURIComponent(query)}`);
        const results = [];
        $('.anime-list .anime-item, .list-anime .anime-item, .anime-card').each((i, el) => {
            const title = $(el).find('.anime-title, .title, h3').text().trim();
            const link = $(el).find('a').attr('href');
            const image = $(el).find('img').attr('src');
            if (title && link) {
                results.push({
                    title,
                    link: link.startsWith('http') ? link : BASE_URL + link,
                    image: image || 'https://via.placeholder.com/180x260?text=No+Image'
                });
            }
        });
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== ENDPOINT 3: Detail Anime ==========
app.get('/api/anime/:slug', async (req, res) => {
    const slug = req.params.slug;
    try {
        const url = slug.startsWith('http') ? slug : `${BASE_URL}/anime/${slug}`;
        const $ = await fetchHTML(url);

        const title = $('h1.entry-title, .title-anime, .anime-title').first().text().trim();
        const sinopsis = $('.sinopsis, .desc, .description').text().trim();
        const image = $('.thumb img, .poster img').attr('src');
        const genre = [];
        $('.genre a, .genres a').each((i, el) => {
            genre.push($(el).text().trim());
        });
        const episodes = [];
        $('.episode-list a, .list-episode a, .eps-item a').each((i, el) => {
            const epTitle = $(el).text().trim();
            const epLink = $(el).attr('href');
            if (epLink) {
                episodes.push({
                    episode: epTitle || `Episode ${i+1}`,
                    link: epLink.startsWith('http') ? epLink : BASE_URL + epLink
                });
            }
        });

        res.json({
            title,
            sinopsis: sinopsis || 'Sinopsis tidak tersedia',
            image: image || 'https://via.placeholder.com/300x450?text=No+Image',
            genre: genre.length ? genre : ['Tidak ada genre'],
            episodes: episodes.slice(0, 50) // batasi 50 episode
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== ENDPOINT 4: Episode (ambil link streaming) ==========
app.get('/api/episode/:url', async (req, res) => {
    const url = req.params.url;
    try {
        const fullUrl = url.startsWith('http') ? url : `${BASE_URL}/episode/${url}`;
        const $ = await fetchHTML(fullUrl);

        // Cari iframe/embed video
        let videoLink = '';
        $('iframe').each((i, el) => {
            const src = $(el).attr('src');
            if (src && (src.includes('youtube') || src.includes('vimeo') || src.includes('drive') || src.includes('kuramanime'))) {
                videoLink = src;
                return false;
            }
        });
        // Cari juga di link download / player
        if (!videoLink) {
            $('.player-embed iframe, .video-player iframe').each((i, el) => {
                const src = $(el).attr('src');
                if (src) { videoLink = src; return false; }
            });
        }
        // Ambil judul episode
        const title = $('h1.entry-title, .episode-title').text().trim();

        res.json({
            title: title || 'Episode',
            video: videoLink || 'https://www.w3schools.com/html/mov_bbb.mp4', // fallback demo
            source: fullUrl
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== ENDPOINT 5: Genre (daftar) ==========
app.get('/api/genres', async (req, res) => {
    try {
        const $ = await fetchHTML(BASE_URL);
        const genres = [];
        $('.genre-list a, .genres a, .menu-genre a').each((i, el) => {
            const name = $(el).text().trim();
            const link = $(el).attr('href');
            if (name && link) {
                genres.push({ name, link: link.startsWith('http') ? link : BASE_URL + link });
            }
        });
        res.json(genres);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== ENDPOINT 6: By Genre ==========
app.get('/api/genre/:slug', async (req, res) => {
    const slug = req.params.slug;
    try {
        const url = slug.startsWith('http') ? slug : `${BASE_URL}/genre/${slug}`;
        const $ = await fetchHTML(url);
        const results = [];
        $('.anime-list .anime-item, .list-anime .anime-item, .anime-card').each((i, el) => {
            const title = $(el).find('.anime-title, .title, h3').text().trim();
            const link = $(el).find('a').attr('href');
            const image = $(el).find('img').attr('src');
            if (title && link) {
                results.push({
                    title,
                    link: link.startsWith('http') ? link : BASE_URL + link,
                    image: image || 'https://via.placeholder.com/180x260?text=No+Image'
                });
            }
        });
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== JALANKAN SERVER ==========
app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ PlayPlay server berjalan di http://localhost:${PORT}`);
    console.log(`📱 Akses dari HP: http://<IP_PC_ANDA>:${PORT}`);
});
