# PlayPlay

Nonton anime sub Indo — backend scraper Kuramanime + frontend statis, satu server.

## Struktur

```
PlayPlay/
├── server.js        # backend Express (API scraper Kuramanime)
├── package.json
├── .gitignore
└── public/
    └── index.html    # frontend
```

## Jalankan lokal (Termux)

```bash
cd PlayPlay
npm install
node server.js
```

Buka browser: `http://localhost:3000` — frontend dan API jalan di server yang sama, jadi tidak perlu ubah `API_BASE`.

## Endpoint API

| Method | Path | Keterangan |
|---|---|---|
| GET | `/api/latest` | Anime rilis terbaru |
| GET | `/api/search?q=` | Pencarian |
| GET | `/api/anime/:slug` | Detail anime + daftar episode |
| GET | `/api/episode/:url` | Link streaming episode |
| GET | `/api/genres` | Daftar genre |
| GET | `/api/genre/:slug` | Anime berdasarkan genre |

## Deploy

Push ke GitHub lalu deploy ke Railway/Render:
- Build command: `npm install`
- Start command: `node server.js` (atau `npm start`)
- Port otomatis terbaca dari `process.env.PORT`

Setelah deploy, buka `https://<domain-kamu>` langsung — tidak perlu ubah kode frontend karena frontend di-serve dari server yang sama.
